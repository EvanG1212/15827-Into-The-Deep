package org.firstinspires.ftc.teamcode.opmodes.auto;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;

public class CommandIntake extends CommandMain {
    private double targetIntakePosition;  
    private double intakeSpeed;          
    private boolean isMoving;              

    public CommandIntake(LinearOpMode opMode, double intakeSpeed, double targetIntakePosition) {
        super(opMode);

        this.intakeSpeed = intakeSpeed;
        this.targetIntakePosition = targetIntakePosition;
    }

    @Override
    public void Start(){
        bot.intake.resetTicks();                     
        bot.intake.setMotorMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER); 
        bot.intake.setMotorMode(DcMotor.RunMode.RUN_TO_POSITION);          
        bot.intake.setPower(intakeSpeed); 
        bot.intake.goToIntakePosition(targetIntakePosition);               
        isMoving = true; 
    }

    @Override
    public void Loop(){
        // Updating telemetry for autonomous mode
        opMode.telemetry.addData("target position intake", targetIntakePosition);
        opMode.telemetry.addData("current position intake", bot.intake.getIntakeTicks());
        opMode.telemetry.addData("intake power", intakeSpeed);
        opMode.telemetry.addData("busy yes or no?", bot.intake.isBusy());
        opMode.telemetry.update();
        
        // Check if the intake has reached the target position
        if (!bot.intake.isBusy()) {
            isMoving = false; 
        }
    }

    @Override
    public void Stop(){
        bot.intake.stop(); // Stop the intake motor
        bot.intake.setMotorMode(DcMotor.RunMode.RUN_USING_ENCODER); 
    }

    @Override
    public boolean IsTaskRunning(){
        return isMoving && bot.intake.isBusy(); 
    }
}
