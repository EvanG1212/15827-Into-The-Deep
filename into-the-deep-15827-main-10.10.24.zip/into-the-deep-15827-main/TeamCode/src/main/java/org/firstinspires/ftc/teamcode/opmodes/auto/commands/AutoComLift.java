package org.firstinspires.ftc.teamcode.opmodes.auto.commands;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;

public class AutoComLift extends AutoCommandMain {
    private int targetTicks;
    private double speed;

    public AutoComLift(LinearOpMode opMode, int targetTicks, double speed) {
        super(opMode);
        this.targetTicks = targetTicks;
        this.speed = speed;
    }

    @Override
    public void Start() {
        bot.lift.resetTicks(); 
        bot.lift.setMotorMode(DcMotor.RunMode.RUN_TO_POSITION); 
        bot.lift.setLiftPower(speed); 
        bot.lift.goToLiftPosition(targetTicks); 
    }

    @Override
    public void Loop() {
   // timmytreey
        opMode.telemetry.addData("current tickys", bot.lift.getLiftTicks());
        opMode.telemetry.addData("tartgety ticks", targetTicks);
        opMode.telemetry.update();
    }

    @Override
    public void Stop() {
        bot.lift.stop();
        bot.lift.setMotorMode(DcMotor.RunMode.RUN_USING_ENCODER); 
    }

    @Override
    public boolean IsTaskRunning() {
        return bot.lift.isBusy(); 
    }
}
//new AutoComLift(this, 2000, 0.5).Run();
