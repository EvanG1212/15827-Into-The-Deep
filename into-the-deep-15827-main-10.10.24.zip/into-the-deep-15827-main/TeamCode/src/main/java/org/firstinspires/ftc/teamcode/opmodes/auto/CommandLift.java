package org.firstinspires.ftc.teamcode.opmodes.auto;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;

public class CommandLift extends CommandMain {
    private double liftSpeed;
    private double targetLiftPosition; 

    public CommandLift(LinearOpMode opMode, double liftSpeed, double targetLiftPosition) {
        super(opMode);

        this.liftSpeed = liftSpeed;
        this.targetLiftPosition = targetLiftPosition;
    }

    @Override
    public void Start(){
        bot.lift.resetTicks();
        bot.lift.setMotorMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        bot.lift.setMotorMode(DcMotor.RunMode.RUN_TO_POSITION);
        bot.lift.goToLiftPosition(targetLiftPosition);
    }

    @Override
    public void Loop(){
        
        opMode.telemetry.addData("Target Lift Position", targetLiftPosition);
        opMode.telemetry.addData("Current Lift Position", bot.lift.getLiftTicks());
        opMode.telemetry.update();
    }

    @Override
    public void Stop(){
        bot.lift.stop(); // 
        bot.lift.setMotorMode(DcMotor.RunMode.RUN_USING_ENCODER); 
    }

    @Override
    public boolean IsTaskRunning(){
        return bot.lift.isBusy();
    }
}
