package org.firstinspires.ftc.teamcode.hardware;

import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;

public class IntakeSubSystem {

    // enum to represent different states of the intake system
    public enum IntakeState {
        IN,     // intake is running inwards
        OUT,    // intake is running outwards
        OFF,    // intake is off
        MANUAL, // intake is in manual control mode
        HOLD    // intake is holding its position
    }

    // PROPERTIES
    private double IN_POWER = 0.5;  // power for intake (may need adjustment)
    private double OUT_POWER = -0.5; // power for outtake (may need adjustment)
    private IntakeState intakeState = IntakeState.OFF; // the curent state of the intake
    private int holdPosition = 0; //the starting position

    // ACTUATORS
    private DcMotorEx motorIntake = null; // declares the motor for like everything

    // CONSTRUCTOR
    public IntakeSubSystem(DcMotorEx motorIntake) {
        this.motorIntake = motorIntake;

        // set motor to brake when it power = 0
        this.motorIntake.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        // tell motor to use encoder bc its special
        this.motorIntake.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    }

    // SETTERS AND GETTERS

    // check if its busy
    public boolean isMotorBusy() {
        return motorIntake.isBusy();
    }

    // set the motor mode
    public void setMotorMode(DcMotor.RunMode mode) {
        motorIntake.setMode(mode);
    }

    // set the motor mode
    public void setMotorBreak(DcMotor.ZeroPowerBehavior mode) {
        motorIntake.setZeroPowerBehavior(mode);
    }

    // gets the current ticks
    public int getTicks() {
        return motorIntake.getCurrentPosition();
    }

    // resets ticks for the motors
    public void resetTicks() {
        motorIntake.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        motorIntake.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    }

    // it sets the powers
    public void setPowers(double inPower, double outPower) {
        IN_POWER = inPower;
        OUT_POWER = -outPower;
    }

    // sets the power in to a positive and out to negative
    public void setPowers(double power) {
        IN_POWER = power;
        OUT_POWER = -power;
    }

    // gets the current intake state and its public so you can do bot.intake.getState to get its state in code same for the one below
    public IntakeState getState() {
        return intakeState;
    }

    // sets the state of the intake, it controls the hold stop and blah blah
    public void setState(IntakeState intakeState) {
        this.intakeState = intakeState;
    }

    // INTAKE FUNCTIONS

    // intake go to a specific position
    public void goToIntakePosition(int targetPosition) {
        motorIntake.setTargetPosition(targetPosition);
        motorIntake.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        motorIntake.setPower(0.5); // hange
        intakeState = IntakeState.HOLD;
    }
    
    // holds the current position
    public void holdpos() {
        if (intakeState != IntakeState.HOLD) {
            holdPosition = motorIntake.getCurrentPosition();
        }
        motorIntake.setTargetPosition(holdPosition);
        motorIntake.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        motorIntake.setPower(0.1); // change
    }

    // set a new position
    public void setHoldPosition(int position) {
        holdPosition = position;
        if (intakeState == IntakeState.HOLD) {
            holdpos();
        }
    }
    
    // stop the intake
    public void stop() {
        motorIntake.setPower(0.0);
    }

    //  run intake at a passed power
    public void in() {
        intakeState = IntakeState.IN;         
        motorIntake.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        motorIntake.setPower(IN_POWER);  
    }

    // run intake at a passed power
    public void in(double power) {
        intakeState = IntakeState.IN;
        motorIntake.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        motorIntake.setPower(power);
    }

    // run the intake at defalut power
    public void out() {
        intakeState = IntakeState.OUT;
        motorIntake.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        motorIntake.setPower(OUT_POWER);
    }

    // run the intake at an out power
    public void out(double power) {
        intakeState = IntakeState.OUT;
        motorIntake.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        motorIntake.setPower(-power);
    }

    // it calls alot
    public void update() {
        switch(intakeState) {
            case IN:
                in();
                break;
            case OUT:
                out();
                break;
            case MANUAL:
                // just does nothing
                break;
            case OFF:
                stop();
                break;
            case HOLD:
                holdpos();
                break;
            default:
                stop();
                break;
        }
    }
}
