package org.firstinspires.ftc.teamcode.hardware;

import com.qualcomm.robotcore.hardware.AnalogInput;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;

// timmy

public class LiftSubSystem {
    // states
    public enum LiftState {
        UP,
        DOWN,
        OFF,
        MANUAL,
        HOLD
    }

    // starting propeties
    private LiftState liftState = LiftState.OFF;
    private int holdPosition = 0;

    // actuators
    private DcMotorEx liftMotor1 = null;
    private DcMotorEx liftMotor2 = null;

    // sensor
    private ElapsedTime timer = new ElapsedTime();

    //limit
    public double MAXIMUM_TICKS = 1000; //NEEDS CHANGING
    public double MINIMUM_TICKS = 0; //NEEDS CHANGING

    // contsrucutor
    public LiftSubSystem(DcMotorEx liftMotor1, DcMotorEx liftMotor2) {
        this.liftMotor1 = liftMotor1;
        this.liftMotor2 = liftMotor2;
        this.liftMotor1.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        this.liftMotor2.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        this.liftMotor1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        this.liftMotor2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    }

    //setter and getter

    // checks if motors are busy
    public boolean isBusy() {
        return liftMotor1.isBusy() || liftMotor2.isBusy();
    }

    // sets the mode for both motors
    public void setMotorMode(DcMotor.RunMode mode) {
        liftMotor1.setMode(mode);
        liftMotor2.setMode(mode);
    }

    // sets power for both lift motors
    public void setLiftPower(double liftPower) {
        liftMotor1.setPower(liftPower);
        liftMotor2.setPower(liftPower);
    }

    // gets the current position of the lift
    public int getLiftTicks() {
        return liftMotor1.getCurrentPosition();
    }

    // resets the encoder ticks to zero
    public void resetTicks() {
        liftMotor1.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        liftMotor2.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        liftMotor1.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        liftMotor2.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    }

    // gets the current state of the lift
    public LiftState getState() {
        return liftState;
    }

    // sets the state of the lift
    public void setState(LiftState liftState) {
        this.liftState = liftState;
    }

    // LIFT FUNCTIONS

    // stops the lift motors
    public void stop() {
        liftMotor1.setPower(0.0);
        liftMotor2.setPower(0.0);
    }

    // moves the lift up
    public void up(double power) {
        liftState = LiftState.UP;
        setLiftPower(power);
    }

    // moves the lift down
    public void down(double power) {
        liftState = LiftState.DOWN;
        setLiftPower(-power);
    }

    // moves the lift manually
    public void lift(double power) {
        liftState = LiftState.MANUAL;
        setLiftPower(power);
    }

    // moves lift to a specific position
    public void goToLiftPosition(int targetPosition, double power) {
        liftMotor1.setTargetPosition(targetPosition);
        liftMotor2.setTargetPosition(targetPosition);
        liftMotor1.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftMotor2.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftMotor1.setPower(Math.abs(power));
        liftMotor2.setPower(Math.abs(power));
        liftState = LiftState.HOLD;
    }

    // holds the current position
    public void holdpos() {
        if (liftState != LiftState.HOLD) {
            holdPosition = getLiftTicks();
        }
        liftMotor1.setTargetPosition(holdPosition);
        liftMotor2.setTargetPosition(holdPosition);
        liftMotor1.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftMotor2.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftMotor1.setPower(0.1); //NEEDS CHANGING
        liftMotor2.setPower(0.1); //NeedS CHANGING
    }

    // sets a new hold position
    public void setHoldPosition(int position) {
        holdPosition = position;
        if (liftState == LiftState.HOLD) {
            holdpos();
        }
    }

    // moves up with limits
    public void upWithLimits(double power) {
        int current_ticks = getLiftTicks();
        if (current_ticks < MAXIMUM_TICKS && power > 0) { 
            lift(power);
        } else {
            stop();
        }
    }

    // moves down with limits
    public void downWithLimits(double power) {
        int current_ticks = getLiftTicks();
        if (current_ticks > MINIMUM_TICKS && power > 0) { 
            lift(-power);
        } else {
            stop();
        }
    }

    // moves lift with limits
    public void liftWithLimits(double power) {
        int current_ticks = getLiftTicks();
        if (power < 0 && current_ticks > MINIMUM_TICKS) {            
            lift(power);
        } else if (power > 0 && current_ticks < MAXIMUM_TICKS) {
            lift(power);
        } else {
            stop();
        }
    }

    // updates the lift state
    public void update() {
        switch(liftState) {
            case UP:
                upWithLimits(0.5);//NeedS CHANGING
                break;
            case DOWN:
                downWithLimits(0.5); //NeedS CHANGING
                break;
            case MANUAL:
                break;
            case OFF:
                stop();
                break;
            case HOLD:
                holdpos();
                break;
            default:
                stop();
                break;
        }
    }
}

