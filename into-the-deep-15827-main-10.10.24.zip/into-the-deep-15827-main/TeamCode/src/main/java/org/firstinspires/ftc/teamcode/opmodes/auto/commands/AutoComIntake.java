package org.firstinspires.ftc.teamcode.opmodes.auto.commands;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import org.firstinspires.ftc.teamcode.hardware.IntakeSubSystem;

public class AutoComIntake extends AutoCommandMain {
    private int targetTicks;
    private double speed;

    public AutoComIntake(LinearOpMode opMode, int targetTicks, double speed) {
        super(opMode);
        this.targetTicks = targetTicks;
        this.speed = speed;
    }

    @Override
    public void Start() {
        bot.intake.resetTicks();
        bot.intake.setPowers(speed); 
        bot.intake.goToIntakePosition(targetTicks);
    }

    @Override
    public void Loop() {
        // Timmy
        opMode.telemetry.addData("current tick", bot.intake.getTicks());
        opMode.telemetry.addData("target tick", targetTicks);
        opMode.telemetry.update();
    }

    @Override
    public void Stop() {
        bot.intake.setState(IntakeSubSystem.IntakeState.OFF);
    }

    @Override
    public boolean IsTaskRunning() {
        return bot.intake.isMotorBusy();
    }
}
//new AutoComIntake(this, "ticks, "speed").Run(); 
