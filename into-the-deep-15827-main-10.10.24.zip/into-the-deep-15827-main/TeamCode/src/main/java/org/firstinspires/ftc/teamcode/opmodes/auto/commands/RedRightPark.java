package org.firstinspires.ftc.teamcode.opmodes.auto.commands;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.opmodes.RobotOpMode;

@Autonomous(name = "Red Left 2024")
public class RedRightPark extends RobotOpMode{
    private ElapsedTime runtime = new ElapsedTime();

    @Override
    public void runOpMode() throws InterruptedException{

        bot.init(hardwareMap);
        bot.initAutoServos();

        telemetry.addLine("Status Initialized :) ");

        telemetry.update();


        while (!isStarted())
        waitForStart();
        runtime.reset();

        if(isStopRequested()) return;

        bot.claw.close();
        sleep(2000);
        bot.claw.vertical();
        new AutoComGyroMecDrive(this,  45,0,0.5).Run();
        bot.claw.open();
        sleep(2000);
        bot.claw.horizontal();
        new AutoComGyroMecDrive(this, 0 ,15,0.4).Run();
        new AutoComGyroMecDrive(this, -45 ,0,0.5).Run();
        new AutoComGyroPIDTurn(this, 0.6, -90).Run();
        new AutoComGyroMecDrive(this, 10 ,0,0.5).Run();
        bot.intake.out(0.3);
        new CommandLift(this, 0.5, 20).Run();
        bot.claw.horizontal();
        bot.claw.close();
        new CommandLift(this, 0.5, 1);
        bot.intake.in(0.5);
        new AutoComGyroMecDrive(this, -15, 0, 0.5);
           new AutocomGyroPIDTurn(this, 0.6, 90);
        new AutoComGyroMecDrive(this, 50, 0, 0.5);
        sleep(4000);
        sleep(1500);
    }
}
