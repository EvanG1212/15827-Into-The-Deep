package org.firstinspires.ftc.teamcode.opmodes.auto;

import org.firstinspires.ftc.teamcode.opmodes.RobotOpMode;
import org.firstinspires.ftc.teamcode.opmodes.auto.commands.AutoComGyroMecDrive;
import org.firstinspires.ftc.teamcode.opmodes.auto.commands.AutoComGyroPIDTurn;
import org.firstinspires.ftc.teamcode.opmodes.auto.commands.AutoComTimeMecDrive;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.util.ElapsedTime;

@Autonomous(name = "blue left backboard")
public class BlueLeftPark extends RobotOpMode{
    private ElapsedTime runtime = new ElapsedTime();

    @Override
    public void runOpMode() throws InterruptedException{

        bot.init(hardwareMap);
        bot.initAutoServos();

        telemetry.addLine("Status Initialized :) ");
        while (!isStarted())
            telemetry.update();

        waitForStart();
        runtime.reset();
        if(isStopRequested()) return;

      // new AutoComGyroMecDrive(this,  0.0 ,30,.3).Run();
        bot.claw.close();
        sleep(3000);
        bot.claw.vertical();
      new AutoComGyroMecDrive(this,  45,0,0.3).Run();
        bot.claw.open();
        sleep(2000);
        bot.claw.horizontal();
        new AutoComGyroMecDrive(this, 0 ,15,0.3).Run();
        new AutoComGyroMecDrive(this, -45 ,0,0.3).Run();
        new AutoComGyroPIDTurn(this, 0.5, -90).Run();
        new AutoComGyroMecDrive(this, 10 ,0,0.5).Run();
        bot.intake.out(0.5);
        new CommandLift(this, 0.5, 20).Run();
        bot.claw.horizontal();
        bot.claw.close();
        bot.lift.upWithLimits(0.5);
        bot.intake.in(0.5);
        new AutoComGyroMecDrive(this, -20, 0, 0.5);
        new AutoComGyroMecDrive(this, 0, 50, 0.5);
        sleep(5000);
      // bot.gate.open();
       sleep(1500);
        //   new AutoComGyroMecDrive(this, 0 ,15,.50).Run();
      //  bot.gate.close();
        sleep(1500);
    }
}
